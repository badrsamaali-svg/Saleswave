# Saleswave Consulting Website

Professionele Next.js website voor Saleswave Consulting - B2B Sales & GTM Strategy Services.

## Tech Stack
- Next.js 14
- React 18
- Tailwind CSS
- Lucide Icons

## Installation & Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment

### Deploy to Vercel (Recommended)

1. Push je code naar GitHub
2. Ga naar [vercel.com](https://vercel.com)
3. Klik "New Project" 
4. Select je GitHub repository
5. Vercel zal automatisch deployen!

### Custom Domain

Na deployment:
1. Ga naar Vercel Project Settings
2. Domains → Add Domain
3. Voeg je custom domain in (bijv. saleswave.be)
4. Volg de DNS instructies

## Aanpassingen

- **Contact Info**: Update in `app/page.jsx` (regel 240-245)
- **Colors**: Tailwind classes in `app/page.jsx`
- **Content**: Alle tekst in `app/page.jsx`

## Support

Voor vragen over de website, contact: badr.samaali@saleswaveconsulting.com
