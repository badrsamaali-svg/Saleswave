import './globals.css'

export const metadata = {
  title: 'Saleswave Consulting | B2B Sales & GTM Strategy',
  description: 'Wij helpen B2B-bedrijven meer deals sluiten met gerichte cold calling, Go-To-Market strategie en email campaigns.',
  icons: {
    icon: '/favicon.ico',
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="nl">
      <body>{children}</body>
    </html>
  )
}
